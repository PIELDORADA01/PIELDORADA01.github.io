# Piel Dorada

A Pen created on CodePen.io. Original URL: [https://codepen.io/PIELDORADA01/pen/QWXqpEm](https://codepen.io/PIELDORADA01/pen/QWXqpEm).

